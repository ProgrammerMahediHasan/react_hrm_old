import { useState } from 'react'

import Layout from './Layout/Layout'
import CreateRole from './pages/roles/CreateRole'
import EditList from './pages/roles/EditRole'
import { BrowserRouter, Route, Routes } from 'react-router-dom'
import RoleList from './pages/roles/RoleList'


import EmployInfo from './pages/roles/EmployInfo'
import UserList from './pages/users/UserList'
import CreateUser from './pages/users/CreateUser'
import DeptList from './pages/department/DeptList'
import CreateDept from './pages/department/CreateDept'
import EditUser from './pages/users/EditUser'
import EditRole from './pages/roles/EditRole'
import DesigList from './pages/designation/DesigList'
import CreateDesig from './pages/designation/CreateDesig'
import EditDept from './pages/department/EditDept'
import EditDesig from './pages/designation/EditDesig'
import EmpList from './pages/employee/EmpList'








function App() {
  const [count, setCount] = useState(0)

  return (
    <>
      
 <BrowserRouter>

      <Routes>
        <Route path="/" element={<Layout />} />


  
        


        <Route path="/role" element={<RoleList />} />
        <Route path="/role/edit/:roleId" element={<EditRole />} />
        <Route path="/role/create" element={<CreateRole />} />
     


        <Route path="/user" element={<UserList />} />
        <Route path="/user/create" element={<CreateUser />} />
        <Route path="/user/edit/:userId" element={<EditUser />} />



        <Route path="/department" element={<DeptList />} />
        <Route path="/department/edit/:deptId" element={<EditDept />} />
        <Route path="/department/create" element={<CreateDept />} />

        <Route path="/designation" element={<DesigList />} />
        <Route path="/designation/create" element={<CreateDesig />} />
        <Route path="/designation/edit/:desigId" element={<EditDesig />} />

        <Route path="/employee" element={<EmpList />} />

         


      </Routes>
    </BrowserRouter>
    </>
  )
}

export default App
