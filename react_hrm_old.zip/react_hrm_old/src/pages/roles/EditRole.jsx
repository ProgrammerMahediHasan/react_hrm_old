import axios from 'axios';
import React, { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';

const EditRole = () => {
  const baseUrl = import.meta.env.VITE_BASE_URL;
  const { roleId } = useParams();

  const [role, setRole] = useState({
    id: '',
    name: ''
  });

  const navigate = useNavigate();

  // Fetch role data
  function fetchRole() {
    axios({
      url: `${baseUrl}/role/find/${roleId}`,
      method: "GET",
      data: {}
    })
      .then((res) => {
        console.log(res.data.role);
        setRole({
          id: res.data.role.id,
          name: res.data.role.name
        });
      })
      .catch((err) => { console.log(err) });
  }

  useEffect(() => {
    fetchRole();
  }, []);

  // Handle input change
  const handleChange = (e) => {
    const { name, value } = e.target;
    setRole(prev => ({
      ...prev,
      [name]: value
    }));
  };

  // Handle form submit
  function handleSubmit(e) {
    e.preventDefault();

    axios({
      url: `${baseUrl}/role/update`,
      method: "PUT",
      data: { role }
    })
      .then((res) => {
        console.log(res.data);
        navigate("/role");
      })
      .catch((err) => { console.log(err) });
  }

  // Back button
  const handleBack = () => {
    navigate(-1);
  };

  return (
    <div
      style={{
        maxWidth: '500px',
        margin: '20px auto',
        padding: '20px',
        border: '1px solid #ccc',
        borderRadius: '8px'
      }}
    >
      {/* Back Button */}
      <button
        onClick={handleBack}
        className="btn btn-secondary mb-3"
        style={{ cursor: 'pointer' }}
      >
        &larr; Back
      </button>

      <h3 className="text-center mb-4">Edit Role</h3>

      <form onSubmit={handleSubmit}>
        <div>
          <label htmlFor="">Name</label> <br />
          <input
            value={role.name}
            name='name'
            type="text"
            onChange={handleChange}
            className="form-control"
          />
        </div>
        <br />
        <br />
        <div>
          <button type="submit" className="btn btn-success">Update</button>
        </div>
      </form>
    </div>
  );
};

export default EditRole;
