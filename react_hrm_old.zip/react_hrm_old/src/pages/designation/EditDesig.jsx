import axios from 'axios';
import React, { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';

const EditDesig = () => {
  const baseUrl = import.meta.env.VITE_BASE_URL;
  const { desigId } = useParams(); // department id

  const [designation, setdesignation] = useState({
    dept_id: '',
    name: '',
    description: ''
  });

  const navigate = useNavigate();

  // Fetch department data
  function fetchdesignation() {
    axios({
      url: `${baseUrl}/designation/find/${desigId}`,
      method: "GET",
    })
      .then((res) => {
        console.log(res.data.designation);
        setdesignation({
          id: res.data.designation.id,
          name: res.data.designation.name,
          description: res.data.designation.description
        });
      })
      .catch((err) => console.log(err));
  }

  useEffect(() => {
    fetchdesignation();
  }, []);

  // Handle input change
  const handleChange = (e) => {
    const { name, value } = e.target;
    setdesignation(prev => ({
      ...prev,
      [name]: value
    }));
  };

  // Handle form submit
  function handleSubmit(e) {
    e.preventDefault();
    axios({
      url: `${baseUrl}/designation/update`,
      method: "PUT",
      data:  designation    // ✔ ONLY THIS LINE FIXED
    })
      .then((res) => {
        console.log(res.data);
        navigate("/designation");
      })
      .catch((err) => console.log(err));
  }

  // Back button
  const handleBack = () => {
    navigate(-1);
  };

  return (
    <div
      style={{
        maxWidth: '500px',
        margin: '20px auto',
        padding: '20px',
        border: '1px solid #ccc',
        borderRadius: '8px'
      }}
    >

      <button
        onClick={handleBack}
        className="btn btn-secondary mb-3"
        style={{ cursor: 'pointer' }}
      >
        &larr; Back
      </button>

      <h3 className="text-center mb-4">Edit Designation</h3>

      <form onSubmit={handleSubmit}>
        {/* Hidden ID */}
        <input type="hidden" name="id" value={designation.id} />

        <label>Designation Name</label>
        <input
          name="name"
          value={designation.name}
          onChange={handleChange}
          type="text"
          className="form-control"
        />

        <label>Description</label>
        <textarea
          name="description"
          value={designation.description}
          onChange={handleChange}
          className="form-control"
          rows="3"
        />

        <br />

        <button type="submit" className="btn btn-success">Update</button>
      </form>
    </div>
  );
};

export default EditDesig;
