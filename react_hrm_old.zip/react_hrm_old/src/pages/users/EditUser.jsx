import axios from 'axios';
import React, { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';

const EditUser = () => {
  const baseUrl = import.meta.env.VITE_BASE_URL;
  const { userId } = useParams();

  const [user, setUser] = useState({
    id: '',
    username: '',
    password: '',
    email: '',
    address: '',
    role_id: ''   // ✅ MISSING FIELD ADDED
  });

  const navigate = useNavigate();

  // Fetch user data
  function fetchUser() {
    axios({
      url: `${baseUrl}/user/find/${userId}`,
      method: "GET",
    })
      .then((res) => {
        console.log(res.data);

        setUser({
          id: res.data.user.id,
          username: res.data.user.username,
          password: res.data.user.password,
          email: res.data.user.email,
          address: res.data.user.address,
          role_id: res.data.user.role_id   // ✅ MISSING FIELD SET
        });
      })
      .catch((err) => console.log(err));
  }

  useEffect(() => {
    fetchUser();
  }, []);

  // Handle input changes
  const handleChange = (e) => {
    const { name, value } = e.target;
    setUser(prev => ({
      ...prev,
      [name]: value
    }));
  };

  // Handle form submit
  function handleSubmit(e) {
    e.preventDefault();

    axios({
      url: `${baseUrl}/user/update`,
      method: "PUT",
      data: user   // ✅ Correct payload format (no wrapper)
    })
      .then((res) => {
        console.log(res.data);
        navigate("/user");
      })
      .catch((err) => console.log(err));
  }

  // Back button function
  const handleBack = () => {
    navigate(-1);
  };

  return (
    <div
      style={{
        maxWidth: '500px',
        margin: '20px auto',
        padding: '20px',
        border: '1px solid #ccc',
        borderRadius: '8px'
      }}
    >

      {/* Back Button */}
      <button
        onClick={handleBack}
        className="btn btn-secondary mb-3"
        style={{ cursor: 'pointer' }}
      >
        &larr; Back
      </button>

      <h3 className="text-center mb-4">Edit User</h3>

      <form onSubmit={handleSubmit}>
        <label>User Name</label>
        <input
          name="username"
          value={user.username}
          onChange={handleChange}
          type="text"
          className="form-control"
        />

        <label>Password</label>
        <input
          name="password"
          value={user.password}
          onChange={handleChange}
          type="text"
          className="form-control"
        />

        <label>Email</label>
        <input
          name="email"
          value={user.email}
          onChange={handleChange}
          type="text"
          className="form-control"
        />

        <label>Address</label>
        <input
          name="address"
          value={user.address}
          onChange={handleChange}
          type="text"
          className="form-control"
        />

        <br />

        <button type="submit" className="btn btn-success">Update</button>
      </form>
    </div>
  );
};

export default EditUser;
