import React from "react";
import { Link } from "react-router-dom"; // ✅ Import Link

const Header = () => {
  const menuItems = [
    { name: "Home", path: "#" },
    { name: "About Us", path: "#" },
    { name: "Contact", path: "#" },
  ];

  const dropdownItems = [
    { name: "Users Section", path: "/user" },
    { name: "Roles Section", path: "/role" },
    { name: "Department Section", path: "/department" },
    { name: "Designation Section", path: "/designation" },
    { name: "Other Actions", path: "#" },
  ];

  return (
    <nav
      className="navbar navbar-expand-lg shadow-sm"
      style={{ background: "linear-gradient(90deg, #8B4513, #A0522D)" }}
    >
      <div className="container-fluid">
        {/* Brand */}
        <Link className="navbar-brand fw-bold text-white fs-4" to="#">
          NextPrime Limited
        </Link>

        {/* Toggler for mobile */}
        <button
          className="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarContent"
          aria-controls="navbarContent"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span className="navbar-toggler-icon" style={{ filter: "invert(1)" }}></span>
        </button>

        {/* Navbar links */}
        <div className="collapse navbar-collapse" id="navbarContent">
          <ul className="navbar-nav me-auto mb-2 mb-lg-0">
            {menuItems.map((item, index) => (
              <li className="nav-item" key={index}>
                <Link className="nav-link text-white" to={item.path}>
                  {item.name}
                </Link>
              </li>
            ))}

            <li className="nav-item dropdown">
              <a
                className="nav-link dropdown-toggle text-white"
                href="#"
                id="manageDropdown"
                role="button"
                data-bs-toggle="dropdown"
                aria-expanded="false"
              >
                USER-ROLE
              </a>
              <ul className="dropdown-menu shadow border-0 rounded-3">
                {dropdownItems.map((item, index) => (
                  <React.Fragment key={index}>
                    <li>
                      <Link className="dropdown-item" to={item.path}>
                        {item.name}
                      </Link>
                    </li>
                    {index < dropdownItems.length - 1 && (
                      <li>
                        <hr className="dropdown-divider" />
                      </li>
                    )}
                  </React.Fragment>
                ))}
              </ul>
            </li>
          </ul>

          {/* Search */}
          <form className="d-flex">
            <input
              className="form-control me-2 rounded-pill"
              type="search"
              placeholder="Search..."
              aria-label="Search"
            />
            <button className="btn btn-light rounded-pill">Search</button>
          </form>

          {/* Optional Login button */}
          <div className="ms-3">
            <button className="btn btn-outline-light rounded-pill">Logout</button>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Header;
